# -*- coding: utf-8 -*-
"""
经营管理蓝图路由 - 经营顾问部分的修改

此文件仅展示 /advisor 路由的修改内容。
需要将此代码替换到原 app/manager/routes.py 文件中的对应位置。

修改说明：
1. 引入 qa_engine 模块
2. 使用 answer_manager_question() 替换原有的直接 API 调用
3. 保持聊天历史管理逻辑
4. 保持 API 未配置时的行为
"""

# ============================================================
# 需要添加的导入（添加到文件顶部的 import 区域）
# ============================================================
# from app.ai import qa_engine  # 添加这一行

# ============================================================
# 修改后的 advisor 路由（替换原有的 advisor 函数）
# ============================================================

# 常量定义
MAX_ADVISOR_TURNS = 10


def get_advisor_chat_history() -> list:
    """
    从session获取经营顾问的聊天历史
    
    Returns:
        聊天历史列表
    """
    import flask
    if 'ai_chat' not in flask.session:
        flask.session['ai_chat'] = {}
    if 'manager' not in flask.session['ai_chat']:
        flask.session['ai_chat']['manager'] = {}
    return flask.session['ai_chat']['manager'].get('advisor', [])


def save_advisor_chat_history(history: list) -> None:
    """
    保存经营顾问聊天历史到session
    
    Args:
        history: 聊天历史列表
    """
    import flask
    if 'ai_chat' not in flask.session:
        flask.session['ai_chat'] = {}
    if 'manager' not in flask.session['ai_chat']:
        flask.session['ai_chat']['manager'] = {}
    flask.session['ai_chat']['manager']['advisor'] = history
    flask.session.modified = True


# 以下是修改后的 advisor 路由函数
# @manager_bp.route('/advisor', methods=['GET', 'POST'])
# @login_required
def advisor():
    """
    经营顾问智能问答页面
    
    使用QA引擎回答关于餐厅经营的问题，支持：
    - 规则匹配的即时回答（常见分析问题）
    - LLM生成的智能建议
    - 基于真实数据的分析
    """
    import flask
    from flask import render_template, request, flash
    from flask_login import current_user
    from app.models import Restaurant
    from app.ai import deepseek_client
    from app.ai import qa_engine  # 新增导入
    
    # 获取当前用户的餐厅
    restaurant = Restaurant.query.filter_by(owner_id=current_user.id).first()
    if not restaurant:
        flash('您还没有创建餐厅', 'warning')
        return render_template('manager/advisor.html', 
                             restaurant=None, 
                             api_configured=False,
                             chat_history=[])
    
    # 检查API是否配置
    api_configured = deepseek_client.is_api_configured()
    
    # 获取聊天历史
    chat_history = get_advisor_chat_history()
    
    # 处理POST请求
    if request.method == 'POST' and api_configured:
        user_question = request.form.get('question', '').strip()
        
        if user_question:
            # 使用QA引擎回答问题
            answer, updated_history = qa_engine.answer_manager_question(
                current_user=current_user,
                restaurant_id=restaurant.id,
                question=user_question,
                chat_history=chat_history,
                model_override=None  # 使用默认模型，或设为 'deepseek-reasoner' 以获取更深入分析
            )
            
            # 保存更新后的历史
            save_advisor_chat_history(updated_history)
            chat_history = updated_history
    
    # 构建显示用的聊天记录
    display_messages = []
    for msg in chat_history:
        display_messages.append({
            'role': msg['role'],
            'content': msg['content'],
            'is_user': msg['role'] == 'user'
        })
    
    return render_template(
        'manager/advisor.html',
        restaurant=restaurant,
        api_configured=api_configured,
        chat_history=display_messages
    )


# ============================================================
# 可选：清除聊天历史的路由
# ============================================================
# @manager_bp.route('/advisor/clear', methods=['POST'])
# @login_required
def clear_advisor_chat():
    """清除经营顾问的聊天历史"""
    import flask
    from flask import redirect, url_for, flash
    
    if 'ai_chat' in flask.session and 'manager' in flask.session['ai_chat']:
        flask.session['ai_chat']['manager'].pop('advisor', None)
        flask.session.modified = True
    
    flash('聊天记录已清除', 'success')
    return redirect(url_for('manager.advisor'))
