# -*- coding: utf-8 -*-
"""
订单蓝图路由 - 菜品问答部分的修改

此文件仅展示 /ask/<dish_id> 路由的修改内容。
需要将此代码替换到原 app/order/routes.py 文件中的对应位置。

修改说明：
1. 引入 qa_engine 模块
2. 使用 answer_dish_question() 替换原有的直接 API 调用
3. 保持聊天历史管理逻辑
4. 保持 API 未配置时的行为
"""

# ============================================================
# 需要添加的导入（添加到文件顶部的 import 区域）
# ============================================================
# from app.ai import qa_engine  # 添加这一行

# ============================================================
# 修改后的 ask 路由（替换原有的 ask 函数）
# ============================================================

# 常量定义（如果原文件中没有的话）
MAX_CHAT_TURNS = 10


def get_ai_chat_history(chat_key: str) -> list:
    """
    从session获取指定key的AI聊天历史
    
    Args:
        chat_key: 聊天会话标识，如 'dish:123'
        
    Returns:
        聊天历史列表
    """
    import flask
    if 'ai_chat' not in flask.session:
        flask.session['ai_chat'] = {}
    if 'order' not in flask.session['ai_chat']:
        flask.session['ai_chat']['order'] = {}
    return flask.session['ai_chat']['order'].get(chat_key, [])


def save_ai_chat_history(chat_key: str, history: list) -> None:
    """
    保存AI聊天历史到session
    
    Args:
        chat_key: 聊天会话标识
        history: 聊天历史列表
    """
    import flask
    if 'ai_chat' not in flask.session:
        flask.session['ai_chat'] = {}
    if 'order' not in flask.session['ai_chat']:
        flask.session['ai_chat']['order'] = {}
    flask.session['ai_chat']['order'][chat_key] = history
    flask.session.modified = True


# 以下是修改后的 ask 路由函数
# @order_bp.route('/ask/<int:dish_id>', methods=['GET', 'POST'])
# @login_required
def ask(dish_id):
    """
    菜品智能问答页面
    
    使用QA引擎回答关于菜品的问题，支持：
    - 规则匹配的即时回答
    - LLM生成的智能回答
    - 跨菜品查询
    """
    import flask
    from flask import render_template, request, flash, redirect, url_for
    from flask_login import current_user
    from app.models import Dish
    from app.ai import deepseek_client
    from app.ai import qa_engine  # 新增导入
    
    # 获取菜品信息
    dish = Dish.query.get_or_404(dish_id)
    
    # 检查API是否配置
    api_configured = deepseek_client.is_api_configured()
    
    # 获取聊天历史
    chat_key = f"dish:{dish_id}"
    chat_history = get_ai_chat_history(chat_key)
    
    # 处理POST请求
    if request.method == 'POST' and api_configured:
        user_question = request.form.get('question', '').strip()
        
        if user_question:
            # 使用QA引擎回答问题
            answer, updated_history = qa_engine.answer_dish_question(
                current_user=current_user,
                dish_id=dish_id,
                question=user_question,
                chat_history=chat_history,
                model_override=None  # 使用默认模型，或设为 'deepseek-chat'
            )
            
            # 保存更新后的历史
            save_ai_chat_history(chat_key, updated_history)
            chat_history = updated_history
    
    # 构建显示用的聊天记录
    display_messages = []
    for msg in chat_history:
        display_messages.append({
            'role': msg['role'],
            'content': msg['content'],
            'is_user': msg['role'] == 'user'
        })
    
    return render_template(
        'order/ask.html',
        dish=dish,
        api_configured=api_configured,
        chat_history=display_messages
    )


# ============================================================
# 可选：清除聊天历史的路由
# ============================================================
# @order_bp.route('/ask/<int:dish_id>/clear', methods=['POST'])
# @login_required
def clear_dish_chat(dish_id):
    """清除指定菜品的聊天历史"""
    import flask
    from flask import redirect, url_for, flash
    
    chat_key = f"dish:{dish_id}"
    if 'ai_chat' in flask.session and 'order' in flask.session['ai_chat']:
        flask.session['ai_chat']['order'].pop(chat_key, None)
        flask.session.modified = True
    
    flash('聊天记录已清除', 'success')
    return redirect(url_for('order.ask', dish_id=dish_id))
